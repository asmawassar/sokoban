function validation(formulaire) {
    if (formulaire.mdp_1.value != formulaire.mdp_2.value) {
        alert('Les deux mots de passe ne sont pas compatibles!');
        return false;
    }
     else if (formulaire.mdp_1.value == formulaire.mdp_2.value) {
        alert('Les deux mots de passe sont compatibles!');
        return true;
    }
}