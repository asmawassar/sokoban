function test(formulaire){
    if(formulaire.nom.value=='')
    alert("saisir votre nom svp");
    if(formulaire.prenom.value=="")
    alert("saisir votre prenom svp");
}