
    var tabImages = new Array("image1.jpeg", "image2.jpg", "image4.jpg");
    var numImage = 0;
    
    function changeImage() {
        document.getElementById("serie").src = tabImages[numImage];
        if (numImage == 2) numImage = 0;
        else numImage++;
        setTimeout("changeImage()", 3000);
    }