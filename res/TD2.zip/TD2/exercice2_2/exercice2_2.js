function bigImage() {
    document.getElementById("myimg").style.width = '50%';
    document.getElementById("myimg").style.height = '50%';
}

function smallImage() {
    document.getElementById("myimg").style.width = '20%';
    document.getElementById("myimg").style.height = '20%';
}